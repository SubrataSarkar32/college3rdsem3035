class Student:
    def __init__(self,name='',date='',members='',age=0):
        self.name=name
        self.date=date
        self.members=members
        self.age=age
    def readData(self):
        self.name=raw_input('Enter name: ')
        self.date=raw_input('Enter a date:')
        self.members=raw_input('Enter member name: ')
        self.age=input('Enter age in years: ')
    def display(self):
        print 'Enter name: ',self.name
        print 'Enter a date:',self.date
        print 'Enter member name: ',self.members
        print 'Enter age in years: ',self.age
class PrimaryStudent(Student):
    def __init__(self):
        Student.__init__(self,activityhours=0)
        self.activityhours=activityhours
    def ReadPrimary(self):
        self.readData()
        self.activityhours=input('Enter activity no. of hours: ')
    def DisplayPrimary(self):
        self.display()
        print 'Activity number of hours: ',self.activityhours

class SecondaryStudent(Student):
    def __init__(self):
        Student.__init__(self,language='')
        self.language=language
    def ReadSecondary(self):
        self.readData()
        self.language=input('Enter language: ')
    def DisplaySecondary(self):
        self.display()
        print 'Language: ',self.language
